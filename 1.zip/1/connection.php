<?php
$servername = "localhost";
$username = "nazrqbfh_nn";
$password = "UJz9FXOK[s!g";
$dbname = "nazrqbfh_naz"; 
?>
