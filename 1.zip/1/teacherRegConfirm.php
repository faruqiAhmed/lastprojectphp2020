<?php session_start(); ?>
<?php 
if(!isset($_SESSION["user"])){ 
    header('Location: index.php');
    exit();
}  
?>
 <?php
if(isset($_POST["registration"]))
{ 
	include 'connection1.php';
	try 
		{
			$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
			// set the PDO error mode to exception
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
			$teaName = $_SESSION["teaName"];
			$teausName = $_SESSION["teausName"];
			$teaemailId = $_SESSION["teaemailId"];
			$password = $_SESSION["password"];
			
	
			$stmt = $conn->query("INSERT INTO `teacherReg`(`id`, `teaName`, `teausName`, `teaemail`, `password`)
					values ('','$teaName','$teausName','$teaemailId','$password')");
			header('Location: administrator.php');
		}
			catch(PDOException $e)
				{
				echo "Error: " . $e->getMessage();
				}
			$conn = null;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <script>
            function goBack() {
                window.history.back();
            }
        </script>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">        
        <link href="css/index.css" rel="stylesheet">
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="font-awesome.css">        
        <title>RegConfirm.jsp</title>
    </head>
    <body style="background-color: #f1f1f1">
		<?php include 'header.php'; ?>
        <!-- Main div start here-->
        <div class="main_body"> 
            <div style="margin-top: 100px;">
                <!--Extra Margin add for menu bar-->
            </div>

            <!-- End of Header Section -->
            <?php 
                
                $teaName =$_POST["teaName"];
                $teausName =$_POST["teausName"];
                $teaemailId = $_POST["teaemailId"];
                $password = $_POST["password"];
                

         
                $_SESSION["teaName"] = $teaName;
                $_SESSION["teausName"] = $teausName;
                $_SESSION["teaemailId"] = $teaemailId;
                $_SESSION["password"] = $password;
                
            ?>
            <!-- All Extra Code Start Here -->
            <div class="adminform">
                <form action="#" method="POST">
                    <div style="font-size: 35px; text-align: center; font-weight: bolder; padding-bottom: 50px; padding-top: 20px;">
                        <u>Registration Teacher Confirm</u>
                    </div>
                    <div>
                        <div class="inputtextitle">
                            Teacher full Name&nbsp;:
                        </div>
                        <div style="display: inline-table; width: 45%;">
                            &nbsp;&nbsp;<?php echo $teaName; ?>
                        </div>
                    </div>
                    <div>
                        <div class="inputtextitle">
                            Teacher User Name&nbsp;:
                        </div>
                        <div style="display: inline-table; width: 45%;">
                            &nbsp;&nbsp;<?php echo $teausName; ?>
                        </div>
                    </div>                    
                    <div>
                        <div class="inputtextitle">
                            Teacher Email ID&nbsp;:
                        </div>
                        <div style="display: inline-table; width: 45%;">
                            &nbsp;&nbsp;<?php echo $teaemailId; ?>
                        </div>
                    </div>
                    <div>
                        <div class="inputtextitle">
                            Password&nbsp;:
                        </div>
                        <div style="display: inline-table; width: 45%;">
                            &nbsp;&nbsp;<?php echo $password; ?>
                        </div>
                    </div>

                    <div style="margin-left: 350px;">                        
                        <div style="display: inline-table;">
                            <input type="submit" value="Go Back" onclick="goBack()" class="input_box" style="margin-bottom: 15px;margin-top: 10px;"/>
                        </div>
                        <div style="display: inline-table;">
                            <input type="submit" name="registration" value="Enroll" style="margin-bottom: 15px;margin-top: 10px;" class="input_box"/>
                        </div>
                    </div>
                </form>
            </div> 
            <!-- Footer Start Here -------------------------------------------------------------------- --> 
            <hr>
            <div class="footer">
                <div class="icon">
                    <a href="#">N@zrul</a>
                </div>
                <div class="icon">
                    <a href="#">Branches</a>
                </div>
                <div class="icon">
                    <a href="#">Courses</a>
                </div>
                <div class="icon">
                    <a href="#">Policy</a>
                </div>
                <div class="icon">
                    <a href="#">Suggest</a>
                </div>
                <div class="icon">
                    <a href="#">Branches</a>
                </div>
                <div class="icon">
                    <a href="#">Career</a>
                </div>
                <div class="icon">
                    <a href="#">Contact US</a>
                </div>
            </div>
        </div>
    </body>
</html>
