<?php               
	$showBox = $_GET["q"];
	
			print("<input type='number' name='due1' placeholder='First instalment Amount' style='display: inline-table; width: 230px; font-size: 15px;' required>
			<div style=\"padding: 5px;display: inline-table;\">
			<div style=\"padding-left: 5px; display: inline-table; margin-left: 30px;\">
			Payment Date</div>
			<div style='display: inline-table;margin-left: 30px;'> 
			<b>:</b>&nbsp;&nbsp;&nbsp;<input type='date' name='paymentDate1' style='display: inline-table; width: 200px; font-size: 12px;' required>&nbsp;
			</div></div>");
?>

