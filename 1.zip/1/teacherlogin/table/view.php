<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>View Records</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>

<h1>View Records</h1>

 <a href="table/profile.php">profile</a></p>

<?php
// connect to the database
include('table/connect-db.php');

// get the records from the database
if ($result = $mysqli->query("SELECT * FROM players ORDER BY id"))
{
// display records if there are records to display
if ($result->num_rows > 0)
{
// display records in a table
echo "<table border='1' cellpadding='10'>";

// set table headers
echo "<tr><th>ID</th><th>First Name</th>
<th>Ailmentname</th>
<th>Middle</th>
<th>Last Name</th>
<th>Image</th>
<th>Dirth date</th>
<th>Age</th>
<th>Parmanent Address</th>
<th>Present Address</th>
<th>Contuct</th>
<th>Gender</th>
<th>DG</th>
<th></th><th></th><th></th></tr>";

while ($row = $result->fetch_object())
{
// set up a row for each record
echo "<tr>";
echo "<td>" . $row->id . "</td>";
echo "<td>" . $row->firstname . "</td>";
echo "<td>" . $row->Ailmentname . "</td>";

echo "<td>" . $row->middle . "</td>";
echo "<td>" . $row->lastname . "</td>";
							echo"<td>".  
                                    '<img src="'.$row->image .'" height="50" width="50" class="img-thumnail" />'  
                               ."</td>" ;
echo "<td>" . $row->birth . "</td>";
echo "<td>" . $row->age . "</td>";
echo "<td>" . $row->paradd . "</td>";
echo "<td>" . $row->preadd . "</td>";
echo "<td>" . $row->contuct . "</td>";
echo "<td>" . $row->gender . "</td>";
echo "<td>" . $row->bg . "</td>";
echo "<td><a href='records.php?id=" . $row->id . "'>Edit</a></td>";
echo "<td><a href='delete.php?id=" . $row->id . "'>Delete</a></td>";
echo "</tr>";
}

echo "</table>";
}
// if there are no records in the database, display an alert message
else
{
echo "No results to display!";
}
}
// show an error if there is an issue with the database query
else
{
echo "Error: " . $mysqli->error;
}

// close database connection
$mysqli->close();

?>

<a href="records.php">Add New Record</a>


</body>
</html>