<?php
/*
Allows the user to both create new records and edit existing records
*/

// connect to the database
include("connect-db.php");

// creates the new/edit record form
// since this form is used multiple times in this file, I have made it a function that is easily reusable
function renderForm( $first ='',$Ailname='', $mid ='',$last ='', $image='',$birth='',$age='',$parAdd='',$preAdd='',$contuct='',$gender='',$bg='', $error = '', $id = '')
{ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>
<?php if ($id != '') { echo "Edit Record"; } else { echo "New Record"; } ?>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<h1>
	<?php 
		if ($id != '') 
			{ echo "Edit Record"; } 
		else 
			{ echo "New Record"; } ?>
</h1>
<?php 
	if ($error != '') 
	{
		echo "<div style='padding:4px; border:1px solid red; color:red'>" . $error. "</div>";
	} ?>

<form action="" method="post">
<div>
<?php if ($id != '') { ?>
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<p>ID: <?php echo $id; ?></p>
<?php } ?>

<strong>first Name: *</strong> <input type="text" name="firstname"
value="<?php echo $first; ?>"/><br/>
<strong>:Ailment name *</strong> <input type="text" name="Ailmentname"
value="<?php echo $Ailname; ?>"/><br/>
<strong>email: *</strong> <input type="email" name="middle"
value="<?php echo $mid; ?>"/><br/>
<strong>place: *</strong> <input type="text" name="lastname"
value="<?php echo $last; ?>"/><br/>
<input type="file" name="image" value="<?php echo $image; ?>" /><br/>
<strong>Birthh Date: *</strong> <input type="text" name="birth"
value="<?php echo $birth; ?>"/><br/>
<strong>Age: *</strong> <input type="text" name="age"
value="<?php echo $age; ?>"/><br/>
<strong>Parmanent Address: *</strong> <textarea  name="paradd" rows="4" cols="50"
value="<?php echo $parAdd; ?>"> </textarea><br/>
<strong>Present Address: *</strong> <textarea name="preadd" rows="4" cols="50"
value="<?php echo $preAdd; ?>"> </textarea><br/>
<strong>Contuct: *</strong> <input type="text" name="contuct"
value="<?php echo $contuct; ?>"/><br/>
<span>
	<strong>
		Gender: *
	</strong>
</span>
<span><input type="radio" name="gender" value="male" > Male</span>
 <span><input type="radio" name="gender" value="female"> Female</span>
 <span> <input type="radio" name="gender" value="other"> Other</span><br/>
<span><strong>BG: *</strong> </span>
 <span><select name="bg" value="<?php echo $bg; ?>" >
  <option value="A+">A+</option>
  <option value="A-">A-</option>
  <option value="B+">B+</option>
  <option value="O+">O+</option>
</select> </span>


<p>* required</p>
<input type="submit" name="submit" value="Submit" />
</div>
</form>
</body>
</html>

<?php }



/*

EDIT RECORD

*/
// if the 'id' variable is set in the URL, we know that we need to edit a record
if (isset($_GET['id']))
{
// if the form's submit button is clicked, we need to process the form
if (isset($_POST['submit']))
{
	// make sure the 'id' in the URL is valid
	if (is_numeric($_POST['id']))
	{
		// get variables from the URL/form
		$id = $_POST['id'];
		$firstname = htmlentities($_POST['firstname'], ENT_QUOTES);
		$Ailname = htmlentities($_POST['Ailmentname'], ENT_QUOTES);
		
		$middle = htmlentities($_POST['middle'], ENT_QUOTES);
		$lastname = htmlentities($_POST['lastname'], ENT_QUOTES);
		$image = addslashes(file_get_contents($_FILES["image"]));
		$birth = htmlentities($_POST['birth'], ENT_QUOTES);
		$age = htmlentities($_POST['age'], ENT_QUOTES);
		$paradd = htmlentities($_POST['paradd'], ENT_QUOTES);
		$preadd = htmlentities($_POST['preadd'], ENT_QUOTES);
		$contuct = htmlentities($_POST['contuct'], ENT_QUOTES);
		$gender = htmlentities($_POST['gender'], ENT_QUOTES);
		$bg = htmlentities($_POST['bg'], ENT_QUOTES);

		// check that firstname and lastname are both not empty
		if ($firstname == '' || $lastname == ''|| $middle== ''|| $image== '')
		{
		// if they are empty, show an error message and display the form
		$error = 'ERROR: Please fill in all required fields!';
		renderForm($firstname, $lastname, $middle, $image,  $error, $id);
		}
		else
		{
			
			// if everything is fine, update the record in the database
			if ($stmt = $mysqli->prepare("UPDATE players SET firstname = ?, middle = ?, lastname = ?, image = ?, birth = ?, age = ?, paradd = ?, preadd = ?, contuct = ?, gender = ?, bg = ?
			WHERE id=?"))
				{
					$stmt->bind_param("sssssssssss",$Ailname, $firstname, $middle, $lastname , $image, $birth,$age,$paradd,$preadd,$contuct,$gender,$bg, $id);
					$stmt->execute();
					$stmt->close();
				}
				// show an error message if the query has an error
			else
				{
					echo "ERROR: could not prepare SQL statement.";
				}

				// redirect the user once the form is updated
			header("Location: view.php");
		}
	}
	// if the 'id' variable is not valid, show an error message
	else
	{
	echo "Error!";
	}
}
// if the form hasn't been submitted yet, get the info from the database and show the form
else
{
// make sure the 'id' value is valid
if (is_numeric($_GET['id']) && $_GET['id'] > 0)
{
// get 'id' from URL
$id = $_GET['id'];

// get the recod from the database
if($stmt = $mysqli->prepare("SELECT * FROM players WHERE id=?"))
{
$stmt->bind_param("i", $id);
$stmt->execute();

$stmt->bind_result($id,$Ailname, $firstname,$middle, $lastname,$image,$birth,$age,$paradd,$preadd,$contuct,$gender,$bg);
$stmt->fetch();

// show the form
renderForm($firstname,$Ailname, $middle, $lastname,$image,$birth,$age,$paradd,$preadd,$contuct,$gender,$bg, NULL, $id);

$stmt->close();
}
// show an error if the query has an error
else
{
echo "Error: could not prepare SQL statement";
}
}
// if the 'id' value is not valid, redirect the user back to the view.php page
else
{
header("Location: view.php");
}
}
}



/*

NEW RECORD

*/
// if the 'id' variable is not set in the URL, we must be creating a new record

// if the form's submit button is clicked, we need to process the form
if (isset($_POST['submit']))
{
	// get the form data
	$firstname = htmlentities($_POST['firstname'], ENT_QUOTES);
	$Ailname= htmlentities($_POST['Ailmentname'], ENT_QUOTES);
	$middle = htmlentities($_POST['middle'], ENT_QUOTES);
	$lastname = htmlentities($_POST['lastname'], ENT_QUOTES);
	$image = htmlentities($_POST['image'], ENT_QUOTES);
	$birth = htmlentities($_POST['birth'], ENT_QUOTES);
		$age = htmlentities($_POST['age'], ENT_QUOTES);
		$paradd = htmlentities($_POST['paradd'], ENT_QUOTES);
		$preadd = htmlentities($_POST['preadd'], ENT_QUOTES);
		$contuct = htmlentities($_POST['contuct'], ENT_QUOTES);
		$gender = htmlentities($_POST['gender'], ENT_QUOTES);
		$bg = htmlentities($_POST['bg'], ENT_QUOTES);

	// check that firstname and lastname are both not empty
	if ($firstname == '' || $lastname == '')
		{
			// if they are empty, show an error message and display the form
			$error = 'ERROR: Please fill in all required fields!';
			renderForm($firstname, $lastname, $error);
		}
	else
	{
		
	// insert the new record into the database
	if ($stmt = $mysqli->prepare("INSERT INTO players (firstname, Ailmentname, middle, lastname,image,birth,age,paradd,preadd,contuct,gender,bg) VALUES (?,?,?, ?,?,?,?,?,?,?,?,?)"))
	{
		$stmt->bind_param("ssssssssssss", $firstname,$Ailname, $middle, $lastname,$image,$birth,$age,$paradd,$preadd,$contuct,$gender,$bg);
		$stmt->execute();
		$stmt->close();
	}
	// show an error if the query has an error
	else
	{
		echo "ERROR: Could not prepare SQL statement.";
	}

	// redirec the user
	header("Location: view.php");
	}

}
// if the form hasn't been submitted yet, show the form
else
{
renderForm();
}


// close the mysqli connection
$mysqli->close();
?>